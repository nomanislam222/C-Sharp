using System;

struct BankAccount
{
    public int ac_number;
    public string ac_holder;
    public int balance;
}

class Bank
{
    static void Main(string[] args)
    {
        BankAccount account = new BankAccount
        {
            ac_number = 62452,
            ac_holder = "Md Noman Islam",
            balance = 1000
        };
        
        Console.WriteLine("Account Number: " + account.ac_number);
        Console.WriteLine("Account Holder: "+account.ac_holder);
        Console.WriteLine("Account Balance: "+account.balance);
        
        Console.Write("Deposite: ");
        int deposite = Convert.ToInt32(Console.ReadLine());
        account.balance += deposite;
        Console.WriteLine("Deposited " + deposite + " TK New balance: "+account.balance);

        Console.Write("Withdraw: ");
        int withdraw = Convert.ToInt32(Console.ReadLine());
        if (account.balance >= 500)
        {
            account.balance -= withdraw;
            Console.WriteLine("Withdrawn " + withdraw + " TK New balance: "+account.balance);
        }
        else
        {
            Console.WriteLine("Insufficient balance for withdrawal.");
        }

       
    }
}
