using System;

struct Students
{
    public string id;
    public int semester;
    public int credit;
    public double cgpa;
};

public class student
{
    public static void Main(string[] args)
    {
      Students[] students = new Students[]
        {
            new Students { id = "22-45453-1", semester = 6, credit = 49, cgpa = 3.65 },
            new Students { id = "19-37398-2", semester = 10, credit = 110, cgpa = 3.60 },
            new Students { id = "21-45453-3", semester = 7, credit = 80, cgpa = 3.85 },
            new Students { id = "23-21282-1", semester = 2, credit = 29, cgpa = 3.45 },
            new Students { id = "21-72628-1", semester = 8, credit = 110, cgpa = 4.00 }
        };

        Console.WriteLine("Scholarship Students (CGPA >= 3.75):");
        foreach (var student in students)
        {
            if (student.cgpa >= 3.75)
            {
                Console.WriteLine($"ID: {student.id}");
            }
        }
        
        Console.WriteLine("\nStudents with more than 50 credits:");
        foreach (var student in students)
        {
            if (student.credit > 50)
            {
                Console.WriteLine($"ID: {student.id}");
            }
        }

        Console.WriteLine("\nStudents with at least 2 semesters and at least 28 credits:");
        foreach (var student in students)
        {
            if (student.semester >= 2 && student.credit >= 28)
            {
                Console.WriteLine($"ID: {student.id}");
            }
        }

        Console.ReadKey();
    }
}
